package com.nt.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.domain.Contact;
import com.nt.service.ContactInfoService;

@Controller
public class ViewContactController {
	@Autowired
	ContactInfoService cntctService;
	
	@RequestMapping("/editContact")
	public String editContact(HttpServletRequest req,Model model) {
			int cid=Integer.parseInt(req.getParameter("contact_Id"));
			Contact contactById = cntctService.getContactById(cid);
			model.addAttribute("contactInfo",contactById);
		return "contact";
	}

	public String deleteContact() {

		// for deleteing contact

		return null;
	}

	public String addContact(Model model) {
		// for adding contacts

		return null;
	}
}
