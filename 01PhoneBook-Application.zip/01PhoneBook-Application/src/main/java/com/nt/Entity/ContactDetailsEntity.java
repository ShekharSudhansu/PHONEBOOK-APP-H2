package com.nt.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "Contact_Details")
public class ContactDetailsEntity {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO)
	private Integer contact_Id;
	private String contact_Name;
	private String contact_Email;
	private long contact_No;
	
	
	 
	public Integer getContact_Id() {
		return contact_Id;
	}
	public void setContact_Id(Integer contact_Id) {
		this.contact_Id = contact_Id;
	}
	public String getContact_Name() {
		return contact_Name;
	}
	public void setContact_Name(String contact_Name) {
		this.contact_Name = contact_Name;
	}
	public String getContact_Email() {
		return contact_Email;
	}
	public void setContact_Email(String contact_Email) {
		this.contact_Email = contact_Email;
	}
	public long getContact_No() {
		return contact_No;
	}
	public void setContact_No(long contact_No) {
		this.contact_No = contact_No;
	}
	
}
