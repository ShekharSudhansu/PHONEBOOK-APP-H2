package com.nt.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.Entity.ContactDetailsEntity;
import com.nt.domain.Contact;
import com.nt.repositry.ContactDetailsRepositry;
@Service
public class ContactInfoServiceImpl implements ContactInfoService {
	@Autowired	
	private ContactDetailsRepositry cntctRepo;
		
		/**
		 * method for adding contact
		 */
	@Override
	public boolean saveContacts(Contact c) {
		ContactDetailsEntity entity=new ContactDetailsEntity();
		BeanUtils.copyProperties(c, entity);
		entity=cntctRepo.save(entity);
		return entity.getContact_Id()>0;
	}

	/**
	 * fetching all records from DB
	 */
	
	@Override
	public List<Contact> displayAllContacts() {
		List<ContactDetailsEntity> ctctEntity = cntctRepo.findAll();
		List<Contact> listContact=new ArrayList();
		//copy cntctntity to listContact
		ctctEntity.forEach(entity->{
			Contact c=new Contact();
			//copy entity to domain
			BeanUtils.copyProperties(entity, c);
			listContact.add(c);
		});
		return listContact;
	}
	
	
	/**
	 * Edit contacts
	 */

	@Override
	public Contact getContactById(Integer cid) {
		ContactDetailsEntity contactDetailsEntity=null;
		Contact c=null;
		Optional<ContactDetailsEntity> optional = cntctRepo.findById(cid);
			if(optional.isPresent()) {
				contactDetailsEntity = optional.get();
				c=new Contact();
				BeanUtils.copyProperties(contactDetailsEntity, c);
			}
		return c;
	}

	@Override
	public boolean updateContact(Contact c) {
		// update contact 
		return false;
	}

	@Override
	public boolean deleteContactById(Integer cid) {
		// delete contact by id from table
		return false;
	}

}
