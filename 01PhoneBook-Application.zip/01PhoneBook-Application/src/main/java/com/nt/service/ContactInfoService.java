package com.nt.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpRequest;

import com.nt.domain.Contact;

public interface ContactInfoService {
	
	public boolean saveContacts(Contact c);
	
	public List<Contact> displayAllContacts();
	
	public Contact getContactById(Integer cid);
	
	public boolean updateContact(Contact c);
	
	public boolean deleteContactById(Integer cid);
	
}
