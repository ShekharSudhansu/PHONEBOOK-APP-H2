package com.nt.repositry;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nt.Entity.ContactDetailsEntity;

public interface ContactDetailsRepositry extends JpaRepository<ContactDetailsEntity,Integer>{

}
